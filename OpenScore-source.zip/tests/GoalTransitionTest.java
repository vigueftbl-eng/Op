import org.openscore.app.GoalTransition;

public class GoalTransitionTest {
    static void check(String expected, String actual) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError("Expected " + expected + " but was " + actual);
        }
    }
    public static void main(String[] args) {
        check("Arsenal", GoalTransition.scorer(0,0,1,0,"Arsenal","Chelsea"));
        check("Chelsea", GoalTransition.scorer(1,0,1,1,"Arsenal","Chelsea"));
        check(null, GoalTransition.scorer(1,1,1,1,"Arsenal","Chelsea"));
        check(null, GoalTransition.scorer(2,0,1,0,"Arsenal","Chelsea"));
        check("Multiple goals", GoalTransition.scorer(1,1,2,3,"Arsenal","Chelsea"));
        System.out.println("PASS: 5 scoring transition cases");
    }
}
