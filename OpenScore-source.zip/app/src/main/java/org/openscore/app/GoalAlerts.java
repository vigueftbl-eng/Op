package org.openscore.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

/** Detect soccer score increments; schedule alarms without requiring exact-alarm access. */
public final class GoalAlerts {
    public static final String CHANNEL = "match_alerts";
    private static final Object LOCK = new Object();
    private GoalAlerts() {}

    public static void scan(Context context, List<Scores.Match> matches) {
        synchronized (LOCK) {
            for (Scores.Match match : matches) {
                if (!Store.following(context, match.key())) continue;
                Store.cache(context, match);
                String last = Store.baseline(context, match.key());
                if (last != null && match.live() && "soccer".equals(match.sport)
                        && Store.alerts(context)) {
                    String[] n = last.split(":");
                    try {
                        int h = Integer.parseInt(n[0]), a = Integer.parseInt(n[1]);
                        String scorer = GoalTransition.scorer(h, a, match.homeScore,
                                match.awayScore, match.home, match.away);
                        if (scorer != null) {
                            String title = "⚽ GOAL · " + scorer;
                            String body = match.home + "  " + match.homeScore + " – "
                                    + match.awayScore + "  " + match.away;
                            String id = match.key() + ":" + match.homeScore + ":" + match.awayScore;
                            schedule(context, id, title, body, Store.delay(context));
                        }
                    } catch (Exception ignored) {}
                }
                Store.baseline(context, match);
            }
        }
    }

    public static void test(Context context) {
        schedule(context, "test:" + System.currentTimeMillis(), "OpenScore test alert",
                "Your notification delay is working.", Store.delay(context));
    }

    public static void ensureChannel(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Match alerts", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Delayed goal alerts for matches you follow");
        nm.createNotificationChannel(channel);
    }

    private static JSONArray getPending(Context c) {
        try { return new JSONArray(Store.prefs(c).getString("pending_alerts", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    private static void savePending(Context c, JSONArray a) {
        Store.prefs(c).edit().putString("pending_alerts", a.toString()).apply();
    }

    private static void schedule(Context context, String id, String title, String body, int delaySeconds) {
        synchronized (LOCK) {
            long due = System.currentTimeMillis() + delaySeconds * 1000L;
            int requestId = ("openscore:"+id).hashCode() & 0x7fffffff;
            JSONArray pending = getPending(context);
            for (int i=0; i<pending.length(); i++) {
                JSONObject old = pending.optJSONObject(i);
                if (old != null && id.equals(old.optString("id"))) return;
            }
            try {
                JSONObject o = new JSONObject();
                o.put("id",id); o.put("title",title); o.put("body",body);
                o.put("due",due); o.put("requestId",requestId);
                pending.put(o);
                savePending(context,pending);
                arm(context,o);
            } catch (Exception ignored) {}
        }
    }
    private static void arm(Context c, JSONObject o) {
        Intent intent = new Intent(c, AlertReceiver.class);
        intent.putExtra("id", o.optString("id"));
        intent.putExtra("title",o.optString("title"));
        intent.putExtra("body",o.optString("body"));
        int req = o.optInt("requestId");
        PendingIntent pi = PendingIntent.getBroadcast(c, req, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        long when = Math.max(System.currentTimeMillis(),o.optLong("due"));
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }
    public static void delivered(Context c, String id) {
        synchronized (LOCK) {
            JSONArray pending = getPending(c);
            for (int i=pending.length()-1; i>=0; i--) {
                JSONObject o = pending.optJSONObject(i);
                if (o != null && id.equals(o.optString("id"))) pending.remove(i);
            }
            savePending(c,pending);
        }
    }
    public static void restore(Context c) {
        synchronized (LOCK) {
            JSONArray pending = getPending(c);
            JSONArray keep = new JSONArray();
            long now = System.currentTimeMillis();
            for (int i=0; i<pending.length(); i++) {
                JSONObject o = pending.optJSONObject(i);
                if (o == null) continue;
                // Avoid notifying about a goal from hours before reboot.
                if (o.optLong("due") + 15 * 60_000L < now) continue;
                keep.put(o);
                arm(c,o);
            }
            savePending(c,keep);
        }
    }
}
