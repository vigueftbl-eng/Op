package org.openscore.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Everything stays on-device: no account, ad SDK or tracking. */
public final class Store {
    private Store() {}
    static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences("openscore", Context.MODE_PRIVATE);
    }
    public static boolean alerts(Context c) { return prefs(c).getBoolean("alerts", true); }
    public static void alerts(Context c, boolean value) { prefs(c).edit().putBoolean("alerts", value).apply(); }
    public static int delay(Context c) { return prefs(c).getInt("delay_seconds", 60); }
    public static void delay(Context c, int seconds) {
        prefs(c).edit().putInt("delay_seconds", Math.max(0, Math.min(seconds, 300))).apply();
    }
    public static boolean hideScores(Context c) { return prefs(c).getBoolean("hide_scores", false); }
    public static void hideScores(Context c, boolean value) {
        prefs(c).edit().putBoolean("hide_scores", value).apply();
    }
    public static Set<String> selectedLeagues(Context c, String sport) {
        String key = "leagues:" + sport;
        if (prefs(c).contains(key)) return new HashSet<>(prefs(c).getStringSet(key, new HashSet<>()));
        Set<String> initial = new HashSet<>();
        for (LeagueCatalog.League l : LeagueCatalog.forSport(sport)) {
            if (l.selectedByDefault) initial.add(l.id());
        }
        return initial;
    }
    public static void selectedLeagues(Context c, String sport, Set<String> ids) {
        prefs(c).edit().putStringSet("leagues:" + sport, new HashSet<>(ids)).apply();
    }
    public static boolean following(Context c, String key) { return follows(c).contains(key); }
    public static Set<String> follows(Context c) {
        return new HashSet<>(prefs(c).getStringSet("follows", new HashSet<>()));
    }
    public static void follow(Context c, Scores.Match m, boolean yes) {
        Set<String> followed = follows(c);
        if (yes) followed.add(m.key()); else followed.remove(m.key());
        prefs(c).edit().putStringSet("follows", followed).apply();
        cache(c, m);
        if (yes) baseline(c, m);
    }
    public static void cache(Context c, Scores.Match m) {
        try { prefs(c).edit().putString("match:"+m.key(), m.toJson().toString()).apply(); }
        catch (Exception ignored) {}
    }
    public static void cacheMany(Context c, List<Scores.Match> matches) {
        SharedPreferences.Editor e = prefs(c).edit();
        for (Scores.Match m : matches) {
            try { e.putString("match:"+m.key(), m.toJson().toString()); }
            catch (Exception ignored) {}
        }
        e.apply();
    }
    public static Scores.Match load(Context c, String key) {
        try {
            String str = prefs(c).getString("match:"+key, null);
            return str == null ? null : Scores.Match.fromJson(new JSONObject(str));
        } catch (Exception ignored) { return null; }
    }
    public static List<Scores.Match> followedMatches(Context c) {
        List<Scores.Match> list = new ArrayList<>();
        for (String key : follows(c)) {
            Scores.Match m = load(c, key);
            if (m != null) list.add(m);
        }
        list.sort((a,b) -> Long.compare(a.kickoff,b.kickoff));
        return list;
    }
    public static void baseline(Context c, Scores.Match m) {
        prefs(c).edit().putString("baseline:" + m.key(), m.homeScore+":"+m.awayScore).apply();
    }
    public static String baseline(Context c, String key) {
        return prefs(c).getString("baseline:" + key, null);
    }
}
