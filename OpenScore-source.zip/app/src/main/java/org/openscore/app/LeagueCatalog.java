package org.openscore.app;

import android.content.Context;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

/** Provider-specific league paths are contained in this catalog. Extend freely. */
public final class LeagueCatalog {
    private LeagueCatalog() {}

    public static final class League {
        public final String sport, path, name, region;
        public final boolean selectedByDefault;
        public League(String sport, String path, String name, String region, boolean selectedByDefault) {
            this.sport = sport; this.path = path; this.name = name;
            this.region = region; this.selectedByDefault = selectedByDefault;
        }
        public String id() { return sport + "/" + path; }
    }

    public static final String[] SPORTS = {"soccer", "basketball", "football", "hockey", "baseball"};
    public static final String[] LABELS = {"Football", "Basketball", "American football", "Ice hockey", "Baseball"};
    public static final String[] ICONS = {"⚽", "🏀", "🏈", "🏒", "⚾"};

    public static List<League> all() {
        List<League> l = new ArrayList<>();
        l.add(new League("soccer","eng.1","Premier League","England",true));
        l.add(new League("soccer","esp.1","La Liga","Spain",true));
        l.add(new League("soccer","ger.1","Bundesliga","Germany",true));
        l.add(new League("soccer","ita.1","Serie A","Italy",true));
        l.add(new League("soccer","fra.1","Ligue 1","France",true));
        l.add(new League("soccer","uefa.champions","Champions League","Europe",true));
        l.add(new League("soccer","uefa.europa","Europa League","Europe",true));
        l.add(new League("soccer","uefa.europa.conf","Conference League","Europe",false));
        l.add(new League("soccer","eng.2","Championship","England",false));
        l.add(new League("soccer","eng.fa","FA Cup","England",false));
        l.add(new League("soccer","eng.league_cup","EFL Cup","England",false));
        l.add(new League("soccer","esp.2","Segunda División","Spain",false));
        l.add(new League("soccer","ger.2","2. Bundesliga","Germany",false));
        l.add(new League("soccer","ita.2","Serie B","Italy",false));
        l.add(new League("soccer","fra.2","Ligue 2","France",false));
        l.add(new League("soccer","ned.1","Eredivisie","Netherlands",false));
        l.add(new League("soccer","por.1","Primeira Liga","Portugal",false));
        l.add(new League("soccer","sco.1","Scottish Premiership","Scotland",false));
        l.add(new League("soccer","tur.1","Süper Lig","Turkey",false));
        l.add(new League("soccer","bel.1","Belgian Pro League","Belgium",false));
        l.add(new League("soccer","usa.1","Major League Soccer","USA",false));
        l.add(new League("soccer","mex.1","Liga MX","Mexico",false));
        l.add(new League("soccer","bra.1","Brasileirão","Brazil",false));
        l.add(new League("soccer","arg.1","Argentine Primera","Argentina",false));
        l.add(new League("soccer","ksa.1","Saudi Pro League","Saudi Arabia",false));
        l.add(new League("soccer","jpn.1","J1 League","Japan",false));
        l.add(new League("soccer","aus.1","A-League","Australia",false));
        l.add(new League("soccer","fifa.world","World Cup","World",false));
        l.add(new League("soccer","uefa.nations","Nations League","Europe",false));
        l.add(new League("soccer","conmebol.libertadores","Copa Libertadores","South America",false));
        l.add(new League("soccer","concacaf.champions","CONCACAF Champions Cup","North America",false));
        l.add(new League("soccer","uefa.wchampions","Women's Champions League","Europe",false));
        l.add(new League("soccer","eng.w.1","Women's Super League","England",false));
        l.add(new League("soccer","usa.nwsl","NWSL","USA",false));

        l.add(new League("basketball","nba","NBA","USA",true));
        l.add(new League("basketball","wnba","WNBA","USA",true));
        l.add(new League("basketball","mens-college-basketball","NCAA Men","USA",false));
        l.add(new League("basketball","womens-college-basketball","NCAA Women","USA",false));
        l.add(new League("football","nfl","NFL","USA",true));
        l.add(new League("football","college-football","NCAA Football","USA",false));
        l.add(new League("hockey","nhl","NHL","USA / Canada",true));
        l.add(new League("baseball","mlb","MLB","USA / Canada",true));
        l.add(new League("baseball","college-baseball","NCAA Baseball","USA",false));
        return l;
    }

    public static List<League> forSport(String sport) {
        List<League> result = new ArrayList<>();
        for (League l: all()) if (l.sport.equals(sport)) result.add(l);
        return result;
    }

    public static List<League> selected(Context context, String sport) {
        Set<String> selection = Store.selectedLeagues(context, sport);
        List<League> result = new ArrayList<>();
        for (League league : forSport(sport)) {
            if (selection.contains(league.id())) result.add(league);
        }
        return result;
    }

    public static String label(String sport) {
        int i = Arrays.asList(SPORTS).indexOf(sport);
        return i < 0 ? sport : LABELS[i];
    }
}
