package org.openscore.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Experimental scoreboard adapter: ESPN's undocumented public endpoints, NOT an official API. */
public final class Scores {
    private Scores() {}
    public static class Match {
        public String id, leagueId, league, sport, home, away, status, state;
        public int homeScore, awayScore;
        public long kickoff;
        public String key() { return leagueId + ":" + id; }
        public boolean live() { return "in".equals(state); }
        public boolean scheduled() { return "pre".equals(state); }
        public String scoreLine() { return scheduled() ? "– : –" : homeScore + " : " + awayScore; }
        public JSONObject toJson() throws JSONException {
            JSONObject o = new JSONObject();
            o.put("id",id); o.put("leagueId",leagueId); o.put("league",league);
            o.put("sport",sport); o.put("home",home); o.put("away",away);
            o.put("status",status); o.put("state",state);
            o.put("homeScore",homeScore); o.put("awayScore",awayScore); o.put("kickoff",kickoff);
            return o;
        }
        public static Match fromJson(JSONObject o) {
            Match m = new Match();
            m.id=o.optString("id"); m.leagueId=o.optString("leagueId");
            m.league=o.optString("league"); m.sport=o.optString("sport");
            m.home=o.optString("home"); m.away=o.optString("away");
            m.status=o.optString("status"); m.state=o.optString("state");
            m.homeScore=o.optInt("homeScore"); m.awayScore=o.optInt("awayScore");
            m.kickoff=o.optLong("kickoff"); return m;
        }
    }
    public static class Result {
        public final List<Match> matches = new ArrayList<>();
        public int failures = 0;
        public int leaguesChecked = 0;
        public String lastError = "";
    }

    public static Result fetch(List<LeagueCatalog.League> leagues, String day) {
        Result result = new Result();
        for (LeagueCatalog.League league : leagues) {
            result.leaguesChecked++;
            try {
                String endpoint = "https://site.api.espn.com/apis/site/v2/sports/"
                        + league.sport + "/" + league.path + "/scoreboard?dates=" + day + "&limit=100";
                JSONObject root = readJson(endpoint);
                JSONArray events = root.optJSONArray("events");
                if (events == null) continue;
                for (int i=0; i<events.length(); i++) {
                    Match m = parse(events.optJSONObject(i), league);
                    if (m != null) result.matches.add(m);
                }
            } catch (Exception ex) {
                result.failures++;
                result.lastError = ex.getClass().getSimpleName() + ": " + ex.getMessage();
            }
        }
        result.matches.sort(Comparator.comparing((Match m) -> m.league)
                .thenComparingLong(m -> m.kickoff));
        return result;
    }

    private static JSONObject readJson(String endpoint) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(endpoint).openConnection();
        connection.setConnectTimeout(6000);
        connection.setReadTimeout(6000);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", "OpenScore/0.1 experimental Android client");
        try {
            int code = connection.getResponseCode();
            if (code != 200) throw new IllegalStateException("HTTP " + code);
            try (InputStream stream = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
                return new JSONObject(body.toString());
            }
        } finally {
            connection.disconnect();
        }
    }

    private static Match parse(JSONObject event, LeagueCatalog.League league) {
        if (event == null) return null;
        JSONArray competitions = event.optJSONArray("competitions");
        JSONObject competition = competitions != null ? competitions.optJSONObject(0) : null;
        if (competition == null) return null;
        JSONArray competitors = competition.optJSONArray("competitors");
        if (competitors == null) return null;
        JSONObject home = null, away = null;
        for (int i=0; i<competitors.length(); i++) {
            JSONObject side = competitors.optJSONObject(i);
            if (side == null) continue;
            if ("home".equals(side.optString("homeAway"))) home = side;
            if ("away".equals(side.optString("homeAway"))) away = side;
        }
        if (home == null || away == null) return null;
        JSONObject status = competition.optJSONObject("status");
        if (status == null) status = event.optJSONObject("status");
        JSONObject type = status == null ? null : status.optJSONObject("type");
        Match m = new Match();
        m.id = event.optString("id");
        m.leagueId = league.id(); m.league = league.name; m.sport=league.sport;
        m.home = home.optJSONObject("team") == null ? "Home" : home.optJSONObject("team").optString("displayName", "Home");
        m.away = away.optJSONObject("team") == null ? "Away" : away.optJSONObject("team").optString("displayName", "Away");
        m.homeScore = score(home.optString("score", "0"));
        m.awayScore = score(away.optString("score", "0"));
        m.state = type == null ? "pre" : type.optString("state", "pre");
        m.status = type == null ? "Scheduled" : type.optString("shortDetail", type.optString("description", "Scheduled"));
        m.kickoff = parseDate(event.optString("date"));
        return m;
    }
    private static int score(String score) {
        try { return Integer.parseInt(score); } catch (Exception e) { return 0; }
    }
    private static long parseDate(String date) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(date).getTime();
        } catch (Exception ex) {
            try {
                SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.US);
                f.setTimeZone(TimeZone.getTimeZone("UTC"));
                return f.parse(date).getTime();
            } catch (Exception ignored) { return System.currentTimeMillis(); }
        }
    }
    public static String day(Date date) { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(date); }
}
