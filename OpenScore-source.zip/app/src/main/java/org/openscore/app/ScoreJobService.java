package org.openscore.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import java.util.List;

/** Android background checks are best-effort: minimum period 15 minutes, not real-time push. */
public final class ScoreJobService extends JobService {
    private static final int JOB_ID = 7021;
    private volatile boolean stopped = false;

    public static void install(Context c) {
        JobScheduler scheduler = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        JobInfo job = new JobInfo.Builder(JOB_ID, new ComponentName(c,ScoreJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(15 * 60_000L)
                .setPersisted(true)
                .build();
        scheduler.schedule(job);
    }

    @Override public boolean onStartJob(JobParameters params) {
        stopped = false;
        new Thread(() -> {
            try {
                if (Store.alerts(this) && !stopped) {
                    // Soccer goals only in v0.1. Background check frequency is OS-controlled.
                    List<LeagueCatalog.League> leagues = LeagueCatalog.selected(this,"soccer");
                    if (!leagues.isEmpty()) {
                        Scores.Result r = Scores.fetch(leagues,Scores.day(new java.util.Date()));
                        if (!stopped && !r.matches.isEmpty()) {
                            Store.cacheMany(this,r.matches);
                            GoalAlerts.scan(this,r.matches);
                        }
                    }
                }
            } finally { jobFinished(params,false); }
        },"OpenScoreJob").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) {
        stopped = true;
        return false;
    }
}
