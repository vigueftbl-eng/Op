package org.openscore.app;

/** Pure Java scoring rule, independently testable without Android. */
public final class GoalTransition {
    private GoalTransition() {}
    public static String scorer(int oldHome, int oldAway, int home, int away,
                                String homeName, String awayName) {
        boolean h = home > oldHome;
        boolean a = away > oldAway;
        if (h && a) return "Multiple goals";
        if (h) return homeName;
        if (a) return awayName;
        return null;
    }
}
