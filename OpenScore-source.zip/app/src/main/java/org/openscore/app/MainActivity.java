package org.openscore.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Zero dependency native Android UI. Original dark visual design, not copied assets. */
public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(9,14,24);
    private static final int CARD=Color.rgb(20,29,45);
    private static final int CARD2=Color.rgb(28,41,60);
    private static final int BORDER=Color.rgb(38,54,73);
    private static final int WHITE=Color.rgb(238,244,250);
    private static final int MUTED=Color.rgb(146,164,186);
    private static final int ACCENT=Color.rgb(33,213,181);
    private static final int LIVE=Color.rgb(254,115,120);
    private static final long REFRESH_MS=90_000L;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout root, content;
    private String sport="soccer", tab="matches";
    private LocalDate date=LocalDate.now();
    private boolean liveOnly=false, loading=false;
    private int generation=0, failures=0;
    private long refreshedAt=0;
    private List<Scores.Match> matches = new ArrayList<>();
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (tab.equals("matches") && date.equals(LocalDate.now())) reload();
            handler.postDelayed(this,REFRESH_MS);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 35) getWindow().setNavigationBarContrastEnforced(false);
        GoalAlerts.ensureChannel(this);
        ScoreJobService.install(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);
        }
        render();
        reload();
    }
    @Override protected void onStart() { super.onStart(); handler.postDelayed(ticker,REFRESH_MS); }
    @Override protected void onStop() { handler.removeCallbacks(ticker); super.onStop(); }
    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }

    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private TextView label(String value, int sp, int color, boolean bold) {
        TextView t=new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private GradientDrawable bg(int color, int stroke, int radius) {
        GradientDrawable b=new GradientDrawable(); b.setColor(color); b.setCornerRadius(dp(radius));
        if (stroke != color) b.setStroke(dp(1),stroke);
        return b;
    }
    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));
    }
    private void space(LinearLayout parent,int height) {
        parent.addView(new View(this),lp(1,height));
    }
    private TextView pill(String value, boolean selected, View.OnClickListener listener) {
        TextView t=label(value,13,selected?BG:WHITE,true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14),dp(10),dp(14),dp(10));
        t.setBackground(bg(selected?ACCENT:CARD2,selected?ACCENT:BORDER,22));
        if (listener!=null) t.setOnClickListener(listener);
        return t;
    }
    private void addRowPill(LinearLayout row,TextView t) {
        LinearLayout.LayoutParams p=lp(-2,-2); p.rightMargin=dp(8); row.addView(t,p);
    }
    private TextView action(String text, View.OnClickListener listener) {
        TextView b=label(text,13,ACCENT,true);
        b.setGravity(Gravity.CENTER); b.setPadding(dp(14),dp(10),dp(14),dp(10));
        b.setBackground(bg(CARD2,BORDER,12)); b.setOnClickListener(listener);
        return b;
    }
    private LinearLayout panel() {
        LinearLayout v=vertical(); v.setPadding(dp(15),dp(14),dp(15),dp(14));
        v.setBackground(bg(CARD,BORDER,17)); return v;
    }
    private void heading(LinearLayout into,String text,String sub) {
        into.addView(label(text,20,WHITE,true));
        if (sub!=null) { space(into,3); into.addView(label(sub,12,MUTED,false)); }
    }

    private void render() {
        root=vertical(); root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                root.setPadding(0,bars.top,0,bars.bottom);
                return insets;
            });
        }
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 35) getWindow().getDecorView().requestApplyInsets();
        header();
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true); scroll.setVerticalScrollBarEnabled(false);
        content=vertical(); content.setPadding(dp(17),dp(8),dp(17),dp(22));
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if ("matches".equals(tab)) drawMatches();
        else if ("following".equals(tab)) drawFollowing();
        else drawSettings();
        bottomNav();
    }

    private void header() {
        LinearLayout outer=vertical(); outer.setPadding(dp(18),dp(17),dp(18),dp(10));
        LinearLayout line=horizontal();
        TextView name=label("OpenScore",27,WHITE,true);
        line.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView live=label("●  LIVE DATA",11,ACCENT,true);
        live.setPadding(dp(11),dp(7),dp(11),dp(7));
        live.setBackground(bg(CARD2,BORDER,18)); line.addView(live);
        outer.addView(line);
        TextView slogan=label("All the action. None of the spoilers.",12,MUTED,false);
        LinearLayout.LayoutParams p=lp(-1,-2); p.topMargin=dp(2); outer.addView(slogan,p);
        root.addView(outer);
    }

    private void drawSports() {
        HorizontalScrollView scroller=new HorizontalScrollView(this);
        scroller.setHorizontalScrollBarEnabled(false);
        LinearLayout row=horizontal(); row.setPadding(0,dp(4),0,dp(8));
        for (int i=0; i<LeagueCatalog.SPORTS.length; i++) {
            final String s=LeagueCatalog.SPORTS[i];
            final String title=LeagueCatalog.ICONS[i]+"  "+LeagueCatalog.LABELS[i];
            addRowPill(row,pill(title,s.equals(sport),v->{
                sport=s; date=LocalDate.now(); liveOnly=false; matches=new ArrayList<>();
                reload();
            }));
        }
        scroller.addView(row); content.addView(scroller);
    }

    private void drawMatches() {
        drawSports(); space(content,9);
        LinearLayout dateRow=horizontal();
        dateRow.addView(action("‹",v->moveDay(-1)),lp(46,44));
        TextView dateText=label(date.format(DateTimeFormatter.ofPattern("EEE, d MMM",Locale.ENGLISH))
                +(date.equals(LocalDate.now())?"  ·  TODAY":""),15,WHITE,true);
        dateText.setGravity(Gravity.CENTER);
        dateRow.addView(dateText,new LinearLayout.LayoutParams(0,dp(44),1));
        dateRow.addView(action("›",v->moveDay(1)),lp(46,44));
        content.addView(dateRow); space(content,12);

        LinearLayout tools=horizontal();
        addRowPill(tools,pill("●  Live only",liveOnly,v->{liveOnly=!liveOnly;render();}));
        TextView leagues=action("Leagues  ⚙",v->pickLeagues());
        tools.addView(leagues);
        TextView refresh=action("↻",v->reload());
        LinearLayout.LayoutParams pr=lp(-2,-2);pr.leftMargin=dp(8);tools.addView(refresh,pr);
        content.addView(tools); space(content,17);
        List<Scores.Match> visible=new ArrayList<>();
        for (Scores.Match m:matches) if(!liveOnly || m.live()) visible.add(m);
        heading(content,"MATCH CENTER",visible.size()+" fixtures · "
                +LeagueCatalog.selected(this,sport).size()+" leagues selected");
        space(content,11);
        if (loading) {
            LinearLayout busy=horizontal();
            ProgressBar spinner=new ProgressBar(this,null,android.R.attr.progressBarStyleSmall);
            busy.addView(spinner,lp(24,24));
            TextView t=label("  Updating scores…",13,MUTED,false);busy.addView(t);
            content.addView(busy);space(content,12);
        }
        if (refreshedAt>0) {
            String message="Updated "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(refreshedAt));
            if(failures>0) message+=" · "+failures+" feeds unavailable";
            content.addView(label(message,11,MUTED,false)); space(content,10);
        }
        if (LeagueCatalog.selected(this,sport).isEmpty()) {
            empty("No leagues selected","Tap Leagues to choose competitions.");
        } else if (visible.isEmpty() && !loading) {
            empty(liveOnly?"No live games right now":"No fixtures returned",
                    failures>0?"Some providers could not be reached. Try refreshing.":
                            "Choose another day or enable more leagues.");
        } else {
            String previous="";
            for (Scores.Match m:visible) {
                if(!previous.equals(m.leagueId)) {
                    if(!previous.isEmpty()) space(content,7);
                    TextView league=label(m.league.toUpperCase(Locale.ROOT),11,MUTED,true);
                    league.setPadding(dp(3),dp(10),0,dp(7)); content.addView(league);
                    previous=m.leagueId;
                }
                matchCard(content,m);
            }
        }
        space(content,18);
        content.addView(label("Experimental free feed · Coverage and delays vary by league.",11,MUTED,false));
    }

    private void moveDay(int by) {
        date=date.plusDays(by); matches=new ArrayList<>();reload();
    }

    private void matchCard(LinearLayout into,Scores.Match m) {
        LinearLayout card=panel();
        LinearLayout meta=horizontal();
        String matchStatus=m.live()?"● LIVE  "+m.status
                :m.scheduled()?time(m.kickoff):"FULL TIME";
        TextView stat=label(matchStatus,11,m.live()?LIVE:MUTED,true);
        meta.addView(stat,new LinearLayout.LayoutParams(0,-2,1));
        TextView follow=label(Store.following(this,m.key())?"★":"☆",27,
                Store.following(this,m.key())?ACCENT:MUTED,true);
        follow.setGravity(Gravity.CENTER);
        follow.setContentDescription("Toggle alerts for "+m.home+" vs "+m.away);
        meta.addView(follow,lp(42,34));
        follow.setOnClickListener(v->{Store.follow(this,m,!Store.following(this,m.key()));render();});
        card.addView(meta);space(card,7);
        boolean hidden=Store.hideScores(this) && !m.scheduled();
        teamLine(card,m.home,hidden?"••":m.scheduled()?"–":String.valueOf(m.homeScore),m.live());
        space(card,5);
        teamLine(card,m.away,hidden?"••":m.scheduled()?"–":String.valueOf(m.awayScore),m.live());
        card.setOnClickListener(v->showDetail(m));
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(8);into.addView(card,p);
    }
    private void teamLine(LinearLayout parent,String team,String score,boolean live) {
        LinearLayout line=horizontal();
        TextView name=label(team,15,WHITE,true);name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        line.addView(name,new LinearLayout.LayoutParams(0,dp(27),1));
        TextView goal=label(score,22,live?ACCENT:WHITE,true);goal.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        line.addView(goal,lp(48,28));parent.addView(line);
    }

    private void showDetail(Scores.Match m) {
        boolean hidden=Store.hideScores(this) && !m.scheduled();
        String score=hidden?"Hidden (Spoiler mode)":m.scoreLine();
        String message=m.league+"\n"+time(m.kickoff)+"\n\n"+m.home+"\n"
                +score+"\n"+m.away+"\n\nStatus: "+m.status
                +"\n\nFollow with ☆ to receive delayed soccer-goal alerts."
                +"\n\nDetailed statistics and lineups are planned for a later release.";
        new AlertDialog.Builder(this).setTitle("Match details")
                .setMessage(message).setPositiveButton("Close",null).show();
    }

    private void drawFollowing() {
        heading(content,"YOUR MATCHES","Tap the star on a match to follow it.");space(content,14);
        List<Scores.Match> followed=Store.followedMatches(this);
        if(followed.isEmpty()) empty("Nothing followed yet","Select a match in the Matches tab and tap ☆.");
        else for(Scores.Match m:followed) {
            TextView l=label(m.league+" · "+LeagueCatalog.label(m.sport),12,MUTED,true);
            l.setPadding(dp(3),dp(9),0,dp(5));content.addView(l);
            matchCard(content,m);
        }
        space(content,14);
        content.addView(label("Followed matches use your last fetched score until refreshed.",12,MUTED,false));
    }

    private void drawSettings() {
        heading(content,"NOTIFICATION SETTINGS","Make alerts match your stream delay.");space(content,16);
        LinearLayout panel=panel();
        LinearLayout toggleRow=horizontal();
        TextView t=label("Goal alerts",17,WHITE,true);
        toggleRow.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        Switch enabled=new Switch(this); enabled.setChecked(Store.alerts(this));
        enabled.setOnCheckedChangeListener((b,checked)->Store.alerts(this,checked));
        toggleRow.addView(enabled);panel.addView(toggleRow);
        panel.addView(label("Only followed football matches. Alerts need notification permission.",12,MUTED,false));
        space(panel,22);
        panel.addView(label("STREAM DELAY",12,ACCENT,true));space(panel,8);
        TextView value=label(Store.delay(this)+" seconds",25,WHITE,true);
        panel.addView(value); space(panel,6);
        SeekBar seek=new SeekBar(this);seek.setMax(60);seek.setProgress(Store.delay(this)/5);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar s,int progress,boolean fromUser) {
                if(fromUser) {Store.delay(MainActivity.this,progress*5);
                    value.setText((progress*5)+" seconds");}
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        panel.addView(seek);
        HorizontalScrollView presets=new HorizontalScrollView(this);
        presets.setHorizontalScrollBarEnabled(false);
        LinearLayout options=horizontal();
        for(int sec:new int[]{0,30,60,90,120,180,300}) {
            addRowPill(options,pill(sec==0?"Instant":sec+"s",sec==Store.delay(this),v->{
                Store.delay(this,sec);render();
            }));
        }
        presets.addView(options);panel.addView(presets);space(panel,12);
        panel.addView(label("If the provider detects a goal at 20:00:00 and you choose 60s, "
                +"OpenScore schedules your alert for 20:01:00. Android may deliver it later.",12,MUTED,false));
        space(panel,18);
        TextView test=action("🔔  Test delayed notification",v->{
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    !=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);
                Toast.makeText(this,"Allow notifications, then try again",Toast.LENGTH_LONG).show();
                return;
            }
            if(!Store.alerts(this)) {
                Toast.makeText(this,"Enable Goal alerts first",Toast.LENGTH_LONG).show();
                return;
            }
            GoalAlerts.test(this);
            Toast.makeText(this,"Scheduled after "+Store.delay(this)+" seconds",Toast.LENGTH_LONG).show();
        });panel.addView(test);
        content.addView(panel);space(content,15);

        LinearLayout spoiler=panel();
        LinearLayout sr=horizontal();
        sr.addView(label("Hide scores (spoiler mode)",16,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        Switch hide=new Switch(this);hide.setChecked(Store.hideScores(this));
        hide.setOnCheckedChangeListener((v,checked)->{Store.hideScores(this,checked);});
        sr.addView(hide);spoiler.addView(sr);
        spoiler.addView(label("Conceal scoreboard scores. Notifications still show results after your chosen delay.",12,MUTED,false));
        content.addView(spoiler);space(content,16);

        LinearLayout info=panel();
        info.addView(label("ABOUT THIS BUILD",12,ACCENT,true));space(info,8);
        info.addView(label("OpenScore v0.1.0  ·  MIT source code",14,WHITE,true));space(info,7);
        info.addView(label("No ads, analytics, account or tracker. Public, undocumented ESPN feeds are experimental and may stop working. Background score checks run about every 15 minutes or later; truly instant closed-app alerts are not available in this version.",12,MUTED,false));
        content.addView(info);
    }

    private void empty(String main,String sub) {
        LinearLayout pane=panel(); pane.setGravity(Gravity.CENTER);
        pane.setPadding(dp(22),dp(35),dp(22),dp(35));
        TextView glyph=label("◉",33,ACCENT,true);glyph.setGravity(Gravity.CENTER);pane.addView(glyph);
        space(pane,13);
        TextView title=label(main,17,WHITE,true);title.setGravity(Gravity.CENTER);pane.addView(title);
        space(pane,5);
        TextView hint=label(sub,13,MUTED,false);hint.setGravity(Gravity.CENTER);pane.addView(hint);
        content.addView(pane);
    }

    private void bottomNav() {
        LinearLayout bar=horizontal();bar.setPadding(dp(12),dp(8),dp(12),dp(8));
        bar.setBackgroundColor(CARD);
        String[] ids={"matches","following","settings"};
        String[] titles={"▦  Matches","☆  Following","⚙  Settings"};
        for(int i=0;i<ids.length;i++) {
            final String id=ids[i];
            TextView btn=label(titles[i],12,tab.equals(id)?ACCENT:MUTED,true);
            btn.setGravity(Gravity.CENTER);btn.setPadding(dp(3),dp(11),dp(3),dp(11));
            if(tab.equals(id))btn.setBackground(bg(CARD2,CARD2,13));
            bar.addView(btn,new LinearLayout.LayoutParams(0,dp(43),1));
            btn.setOnClickListener(v->{tab=id;render();});
        }
        root.addView(bar);
    }

    private void pickLeagues() {
        List<LeagueCatalog.League> available=LeagueCatalog.forSport(sport);
        String[] options=new String[available.size()];
        boolean[] checked=new boolean[available.size()];
        Set<String> selected=Store.selectedLeagues(this,sport);
        for(int i=0;i<available.size();i++) {
            options[i]=available.get(i).name+"  ·  "+available.get(i).region;
            checked[i]=selected.contains(available.get(i).id());
        }
        new AlertDialog.Builder(this).setTitle("Choose leagues")
                .setMultiChoiceItems(options,checked,(dialog,index,value)->checked[index]=value)
                .setNeutralButton("All",(dialog,which)->{
                    Set<String> all=new HashSet<>();
                    for(LeagueCatalog.League l:available)all.add(l.id());
                    Store.selectedLeagues(this,sport,all);matches=new ArrayList<>();reload();
                })
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Save",(dialog,which)->{
                    Set<String> chosen=new HashSet<>();
                    for(int i=0;i<available.size();i++)if(checked[i])chosen.add(available.get(i).id());
                    Store.selectedLeagues(this,sport,chosen);matches=new ArrayList<>();reload();
                }).show();
    }

    private void reload() {
        String requestedSport=sport;
        LocalDate requestedDate=date;
        List<LeagueCatalog.League> selected=LeagueCatalog.selected(this,requestedSport);
        int request=++generation;
        loading=true;render();
        executor.submit(()->{
            Scores.Result result=Scores.fetch(selected,requestedDate.format(DateTimeFormatter.BASIC_ISO_DATE));
            // Store scores in a cache and use only observed transitions as goal events.
            if(!result.matches.isEmpty()) {
                Store.cacheMany(this,result.matches);
                // Only present-day results may generate notification alerts.
                if(requestedDate.equals(LocalDate.now()))GoalAlerts.scan(this,result.matches);
            }
            runOnUiThread(()->{
                if(isFinishing() || isDestroyed() || generation!=request) return;
                loading=false;
                matches=result.matches;failures=result.failures;refreshedAt=System.currentTimeMillis();
                render();
            });
        });
    }

    private String time(long timestamp) {
        return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(timestamp));
    }
}
