# OpenScore v0.1 — architecture

```text
┌────────────────────── Android app ──────────────────────┐
│ MainActivity (native Java UI; sport/date/leagues)       │
│                 │                                      │
│                 ▼                                      │
│ Scores.fetch()  ──────► ESPN public JSON (experimental) │
│                 │                                      │
│                 ▼                                      │
│ Store (on-device SharedPreferences and match cache)     │
│                 │                                      │
│                 ▼                                      │
│ GoalAlerts.scan() ────► compare followed soccer scores  │
│                 │                                      │
│                 ▼                                      │
│ AlarmManager inexact delayed alarm ───► AlertReceiver  │
│                                                        │
│ ScoreJobService ──────► background checks (>= 15 min)  │
│ BootReceiver ─────────► restore pending alerts on boot  │
└────────────────────────────────────────────────────────┘
```

## Layers
- **LeagueCatalog**: curated sport + league mapping, user-selectable.
- **Scores**: isolated provider adapter; replace for official or licensed data without redesigning UI.
- **Store**: user settings, following, score snapshots, cached matches, and scheduled alert metadata. No cloud sync.
- **GoalTransition**: unit-tested score increment rule. A score correction is not a goal; multiple score increments between polls result in one combined alert.
- **GoalAlerts / AlertReceiver**: follow-only soccer goal detection, event dedup, configurable per-device delay (0–300 seconds), OS-managed alarm and notification channel.
- **ScoreJobService**: Android JobScheduler background fetch of selected soccer leagues. Android may run it later than the 15-minute minimum. No guarantee of real-time delivery.
- **MainActivity**: native UI including dark scores, date browse, five sports, league chooser, match favorites, settings, test alert, and spoiler switch.

## End-to-end notification scenario
1. User follows match before a goal; a baseline snapshot is stored.
2. A subsequent provider response increases 0:0 to 1:0 while event status is `in`.
3. Scorer name is inferred from which *team score* increased (not individual player).
4. GoalAlerts sets an alarm for `detectedAt + userDelay`. This is **after detection**, not necessarily after the real-world goal.
5. Android delivers the inexact alarm when able, and AlertReceiver posts the notification (subject to Android 13+ permission).
6. Pending alarms are restored after device reboot; stale alarms (>15 minutes late) are discarded.

## Limitations and reliability
- Foreground polling is approximately once per 90 seconds; **not** an instant push stream.
- Background JobScheduler checks are **at least** 15 minutes apart and may be delayed. If the match was already 2–0 on the first observation, previous goal events cannot be recovered.
- Selected historical dates never produce goal notifications.
- For now, goal alerts are for soccer only. Other sports have scores and followed-match lists.
- Alert delay applies to notifications, not provider updates or scoreboard cards. Spoiler mode hides scores visually but needs further refinement.
- Matches, ratings, player profiles, lineups, world-wide leagues, in-game alerts for other sports, news, and polished branding are future phases.
- Player names and goal times are not available from simple score-delta detection.
- `AlarmManager.setAndAllowWhileIdle` is inexact; battery constraints can add delivery delay. Force-stopping the app prevents alarms and jobs until reopened.
- ESPN endpoints are not officially supported/licensed for third-party apps by virtue of being accessible. Check rights before distribution; use a licensed API for production.

## Next architecture stage
To support low-latency alerts while the Android app is closed:
- Shared centralized ingest worker with a properly licensed fast live-score API
- Durable event store + goal/event IDs + dedup + per-user follow subscriptions
- User-specific stream delay queue (durable delayed jobs)
- Firebase Cloud Messaging for push (free-tier availability subject to Google policies)
- Caching, quotas, audit trails, rate limiting, regional fallbacks, observability and a privacy policy
- Separate authenticated sync for preferences, if desired
