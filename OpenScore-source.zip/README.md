# OpenScore ⚽

**An open-source, ad-free Android live-score MVP.** Football, basketball, NFL, NHL and MLB. Native dark UI, selectable leagues, match favorites, a spoiler switch and delayed goal notifications. Licensed **MIT** for the app's original source code.

> **Status: source project / experimental MVP.** Created as a buildable Android Gradle project. The archive does **not** include a compiled APK, and has not been run on a device in this environment. Use the GitHub Actions workflow to build/test the APK. Sports provider is unofficial and may change or deny requests. See [Architecture](docs/ARCHITECTURE.md).

## Implemented in v0.1
- Android 8+ native Java app (no ads, accounts, analytics SDKs or paywalls)
- Modern dark match list with sport tabs and date navigation
- Curated catalog of 30+ soccer competitions plus basketball/NFL/NHL/MLB, choose which to query
- Scoreboard from ESPN's publicly accessible but **undocumented** JSON endpoint
- Match follow/unfollow and local followed-match cache
- Goal alerts when the **observed** score of a followed soccer match increases
- Delay slider 0–300 seconds, including preset buttons
- Delayed test notifications and Android 13+ permission request
- Background checks using Android JobScheduler (minimum ~15 min, actual time varies)
- Pending alarm recovery after reboot, dedup on observed score change
- Basic spoiler setting to hide scoreboard scores
- GitHub Actions workflow to compile an APK

## What is **not** implemented yet
- Guaranteed rapid background alerts, server push or every league in the world
- Comprehensive player profiles, xG, lineups, odds, player ratings, commentary, translations, or score widgets
- Goal scorer identity, match incident feed, true goal timestamps, sport-specific alerts outside soccer
- Exact-to-the-second notifications (Android may delay inexact alarms)
- Publishing rights for third-party match data, team logos, images or editorial content
- Comprehensive integration/device testing or a polished production release

## Build on GitHub from a PHONE (Android)

1. Download the `OpenScore-source.zip` archive from the chat and save it to your phone.
2. Sign in at [github.com](https://github.com/) and create a **new public repository** called `OpenScore`, ticking **Add a README file** so the `main` branch exists.
3. In that repository select **Code → Codespaces → Create codespace on main** (choose a browser/Desktop Site if mobile UI hides it).
4. In Codespaces' terminal, upload `OpenScore-source.zip` from your phone using the file explorer upload menu. Move the zip into the repository folder if necessary, then run:
   ```bash
   unzip -o OpenScore-source.zip -d .
   rm OpenScore-source.zip
   git add .
   git commit -m "Initial OpenScore Android MVP"
   git push origin main
   ```
   The ZIP is flattened so `app/`, `settings.gradle`, and `.github/` land at the repository root.
5. Open the repository's **Actions** tab → **Build Android APK**. It will run automatically on your push (or use **Run workflow**).
6. Open the successful workflow run and download the **OpenScore-debug-APK** artifact; extract `app-debug.apk` and install it on Android. Your phone may require permission to install APKs from the browser or file manager.
7. Open OpenScore, allow notifications, follow a live soccer match with ☆ and set a delay under **Settings**. Use **Test delayed notification** to check permissions/alarm delivery.

> GitHub Codespaces availability/quotas vary by account. Alternative: unzip locally and upload project files using a Git client that preserves directories and hidden `.github` workflows, or use Android Studio on a PC.

## Build in Android Studio
- Install Android Studio and Android SDK **35**.
- Open the extracted `OpenScore` directory (contains `settings.gradle`).
- Use JDK 17 and sync Gradle.
- **Build → Build APK(s)**, or execute `gradle :app:assembleDebug` with an installed Gradle 8.10.2. This source archive uses GitHub Actions' Gradle installation instead of shipping a Gradle wrapper binary.
- Expected APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Data rights / provider disclosure
The app currently uses endpoints of the form:

`https://site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard?dates=YYYYMMDD&limit=100`

They are not an officially supported third-party API, and access does **not** imply permission to redistribute third-party data. Do not publish/distribute a production app that relies on them without checking applicable ESPN rights and terms. For a public app, switch `Scores.java` to a data provider whose licence permits your intended use. Apps can be open-source even when they use separately licensed data.

## Privacy and costs
No ad network, trackers, login, payment code or personal-data upload is included. No API key is needed for the experimental source; the provider can change availability or throttle traffic. Favorites and settings are stored locally using Android SharedPreferences. A future server-based realtime architecture may introduce hosting and data licensing costs.

## Tests
Run the pure Java scoring transition test anywhere with Java 17+:
```bash
mkdir -p /tmp/openscore-tests
javac -d /tmp/openscore-tests app/src/main/java/org/openscore/app/GoalTransition.java tests/GoalTransitionTest.java
java -cp /tmp/openscore-tests GoalTransitionTest
```

## Contributing
Source code MIT licensed. Provider data is **not** included under MIT. Contributions for adapters using authorized data sources, accessibility, localization, rate-limiting, tests, and more leagues welcome.
